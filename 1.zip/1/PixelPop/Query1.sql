-- QUERY 1 Sort Products based on Quantity
select *
from sql_Inventory.Product
order by Quantity ; 
